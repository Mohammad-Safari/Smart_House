/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/Mohammad/Projects/Logic Lab/Xilinix ISE/Final/module2_gas_detector/module2_gas_detector.v";
static unsigned int ng1[] = {0U, 0U};
static unsigned int ng2[] = {1U, 0U};
static unsigned int ng3[] = {8U, 0U};
static unsigned int ng4[] = {16U, 0U};
static unsigned int ng5[] = {9U, 0U};
static unsigned int ng6[] = {17U, 0U};
static unsigned int ng7[] = {24U, 0U};
static unsigned int ng8[] = {10U, 0U};
static unsigned int ng9[] = {11U, 0U};
static unsigned int ng10[] = {12U, 0U};
static unsigned int ng11[] = {13U, 0U};
static unsigned int ng12[] = {14U, 0U};
static unsigned int ng13[] = {25U, 0U};
static unsigned int ng14[] = {26U, 0U};
static unsigned int ng15[] = {27U, 0U};
static unsigned int ng16[] = {28U, 0U};
static unsigned int ng17[] = {29U, 0U};
static unsigned int ng18[] = {30U, 0U};
static unsigned int ng19[] = {31U, 0U};
static unsigned int ng20[] = {18U, 0U};
static unsigned int ng21[] = {19U, 0U};
static unsigned int ng22[] = {20U, 0U};
static unsigned int ng23[] = {21U, 0U};
static unsigned int ng24[] = {22U, 0U};
static int ng25[] = {0, 0};
static int ng26[] = {2, 0};
static int ng27[] = {1, 0};



static void Always_51_0(char *t0)
{
    char t4[8];
    char *t1;
    char *t2;
    char *t3;
    char *t5;
    char *t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    char *t12;
    char *t13;
    char *t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    char *t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    char *t29;
    char *t30;

LAB0:    t1 = (t0 + 6272U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(51, ng0);
    t2 = (t0 + 7088);
    *((int *)t2) = 1;
    t3 = (t0 + 6304);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(52, ng0);
    t5 = (t0 + 4632U);
    t6 = *((char **)t5);
    memset(t4, 0, 8);
    t5 = (t6 + 4);
    t7 = *((unsigned int *)t5);
    t8 = (~(t7));
    t9 = *((unsigned int *)t6);
    t10 = (t9 & t8);
    t11 = (t10 & 1U);
    if (t11 != 0)
        goto LAB8;

LAB6:    if (*((unsigned int *)t5) == 0)
        goto LAB5;

LAB7:    t12 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t12) = 1;

LAB8:    t13 = (t4 + 4);
    t14 = (t6 + 4);
    t15 = *((unsigned int *)t6);
    t16 = (~(t15));
    *((unsigned int *)t4) = t16;
    *((unsigned int *)t13) = 0;
    if (*((unsigned int *)t14) != 0)
        goto LAB10;

LAB9:    t21 = *((unsigned int *)t4);
    *((unsigned int *)t4) = (t21 & 1U);
    t22 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t22 & 1U);
    t23 = (t4 + 4);
    t24 = *((unsigned int *)t23);
    t25 = (~(t24));
    t26 = *((unsigned int *)t4);
    t27 = (t26 & t25);
    t28 = (t27 != 0);
    if (t28 > 0)
        goto LAB11;

LAB12:    xsi_set_current_line(52, ng0);
    t2 = (t0 + 5352);
    t3 = (t2 + 56U);
    t5 = *((char **)t3);
    t6 = (t0 + 5192);
    xsi_vlogvar_assign_value(t6, t5, 0, 0, 5);

LAB13:    goto LAB2;

LAB5:    *((unsigned int *)t4) = 1;
    goto LAB8;

LAB10:    t17 = *((unsigned int *)t4);
    t18 = *((unsigned int *)t14);
    *((unsigned int *)t4) = (t17 | t18);
    t19 = *((unsigned int *)t13);
    t20 = *((unsigned int *)t14);
    *((unsigned int *)t13) = (t19 | t20);
    goto LAB9;

LAB11:    xsi_set_current_line(52, ng0);
    t29 = ((char*)((ng1)));
    t30 = (t0 + 5192);
    xsi_vlogvar_assign_value(t30, t29, 0, 0, 5);
    goto LAB13;

}

static void Always_58_1(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    int t8;
    char *t9;
    char *t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    char *t16;
    char *t17;

LAB0:    t1 = (t0 + 6520U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(58, ng0);
    t2 = (t0 + 7104);
    *((int *)t2) = 1;
    t3 = (t0 + 6552);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(59, ng0);
    t4 = (t0 + 5192);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);

LAB5:    t7 = ((char*)((ng1)));
    t8 = xsi_vlog_unsigned_case_compare(t6, 5, t7, 5);
    if (t8 == 1)
        goto LAB6;

LAB7:    t2 = ((char*)((ng2)));
    t8 = xsi_vlog_unsigned_case_compare(t6, 5, t2, 5);
    if (t8 == 1)
        goto LAB8;

LAB9:    t2 = ((char*)((ng3)));
    t8 = xsi_vlog_unsigned_case_compare(t6, 5, t2, 5);
    if (t8 == 1)
        goto LAB10;

LAB11:    t2 = ((char*)((ng4)));
    t8 = xsi_vlog_unsigned_case_compare(t6, 5, t2, 5);
    if (t8 == 1)
        goto LAB12;

LAB13:    t2 = ((char*)((ng5)));
    t8 = xsi_vlog_unsigned_case_compare(t6, 5, t2, 5);
    if (t8 == 1)
        goto LAB14;

LAB15:    t2 = ((char*)((ng8)));
    t8 = xsi_vlog_unsigned_case_compare(t6, 5, t2, 5);
    if (t8 == 1)
        goto LAB16;

LAB17:    t2 = ((char*)((ng9)));
    t8 = xsi_vlog_unsigned_case_compare(t6, 5, t2, 5);
    if (t8 == 1)
        goto LAB18;

LAB19:    t2 = ((char*)((ng10)));
    t8 = xsi_vlog_unsigned_case_compare(t6, 5, t2, 5);
    if (t8 == 1)
        goto LAB20;

LAB21:    t2 = ((char*)((ng11)));
    t8 = xsi_vlog_unsigned_case_compare(t6, 5, t2, 5);
    if (t8 == 1)
        goto LAB22;

LAB23:    t2 = ((char*)((ng12)));
    t8 = xsi_vlog_unsigned_case_compare(t6, 5, t2, 5);
    if (t8 == 1)
        goto LAB24;

LAB25:    t2 = ((char*)((ng7)));
    t8 = xsi_vlog_unsigned_case_compare(t6, 5, t2, 5);
    if (t8 == 1)
        goto LAB26;

LAB27:    t2 = ((char*)((ng13)));
    t8 = xsi_vlog_unsigned_case_compare(t6, 5, t2, 5);
    if (t8 == 1)
        goto LAB28;

LAB29:    t2 = ((char*)((ng14)));
    t8 = xsi_vlog_unsigned_case_compare(t6, 5, t2, 5);
    if (t8 == 1)
        goto LAB30;

LAB31:    t2 = ((char*)((ng15)));
    t8 = xsi_vlog_unsigned_case_compare(t6, 5, t2, 5);
    if (t8 == 1)
        goto LAB32;

LAB33:    t2 = ((char*)((ng16)));
    t8 = xsi_vlog_unsigned_case_compare(t6, 5, t2, 5);
    if (t8 == 1)
        goto LAB34;

LAB35:    t2 = ((char*)((ng17)));
    t8 = xsi_vlog_unsigned_case_compare(t6, 5, t2, 5);
    if (t8 == 1)
        goto LAB36;

LAB37:    t2 = ((char*)((ng18)));
    t8 = xsi_vlog_unsigned_case_compare(t6, 5, t2, 5);
    if (t8 == 1)
        goto LAB38;

LAB39:    t2 = ((char*)((ng19)));
    t8 = xsi_vlog_unsigned_case_compare(t6, 5, t2, 5);
    if (t8 == 1)
        goto LAB40;

LAB41:    t2 = ((char*)((ng6)));
    t8 = xsi_vlog_unsigned_case_compare(t6, 5, t2, 5);
    if (t8 == 1)
        goto LAB42;

LAB43:    t2 = ((char*)((ng20)));
    t8 = xsi_vlog_unsigned_case_compare(t6, 5, t2, 5);
    if (t8 == 1)
        goto LAB44;

LAB45:    t2 = ((char*)((ng21)));
    t8 = xsi_vlog_unsigned_case_compare(t6, 5, t2, 5);
    if (t8 == 1)
        goto LAB46;

LAB47:    t2 = ((char*)((ng22)));
    t8 = xsi_vlog_unsigned_case_compare(t6, 5, t2, 5);
    if (t8 == 1)
        goto LAB48;

LAB49:    t2 = ((char*)((ng23)));
    t8 = xsi_vlog_unsigned_case_compare(t6, 5, t2, 5);
    if (t8 == 1)
        goto LAB50;

LAB51:    t2 = ((char*)((ng24)));
    t8 = xsi_vlog_unsigned_case_compare(t6, 5, t2, 5);
    if (t8 == 1)
        goto LAB52;

LAB53:
LAB54:    goto LAB2;

LAB6:    xsi_set_current_line(60, ng0);
    t9 = (t0 + 4312U);
    t10 = *((char **)t9);
    t9 = (t10 + 4);
    t11 = *((unsigned int *)t9);
    t12 = (~(t11));
    t13 = *((unsigned int *)t10);
    t14 = (t13 & t12);
    t15 = (t14 != 0);
    if (t15 > 0)
        goto LAB55;

LAB56:    xsi_set_current_line(60, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 5352);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 5);

LAB57:    goto LAB54;

LAB8:    xsi_set_current_line(61, ng0);
    t3 = (t0 + 4312U);
    t4 = *((char **)t3);
    t3 = (t4 + 4);
    t11 = *((unsigned int *)t3);
    t12 = (~(t11));
    t13 = *((unsigned int *)t4);
    t14 = (t13 & t12);
    t15 = (t14 != 0);
    if (t15 > 0)
        goto LAB58;

LAB59:    xsi_set_current_line(61, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 5352);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 5);

LAB60:    goto LAB54;

LAB10:    xsi_set_current_line(63, ng0);
    t3 = (t0 + 4312U);
    t4 = *((char **)t3);
    t3 = (t4 + 4);
    t11 = *((unsigned int *)t3);
    t12 = (~(t11));
    t13 = *((unsigned int *)t4);
    t14 = (t13 & t12);
    t15 = (t14 != 0);
    if (t15 > 0)
        goto LAB61;

LAB62:    xsi_set_current_line(63, ng0);
    t2 = ((char*)((ng5)));
    t3 = (t0 + 5352);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 5);

LAB63:    goto LAB54;

LAB12:    xsi_set_current_line(64, ng0);
    t3 = (t0 + 4312U);
    t4 = *((char **)t3);
    t3 = (t4 + 4);
    t11 = *((unsigned int *)t3);
    t12 = (~(t11));
    t13 = *((unsigned int *)t4);
    t14 = (t13 & t12);
    t15 = (t14 != 0);
    if (t15 > 0)
        goto LAB64;

LAB65:    xsi_set_current_line(64, ng0);
    t2 = ((char*)((ng7)));
    t3 = (t0 + 5352);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 5);

LAB66:    goto LAB54;

LAB14:    xsi_set_current_line(66, ng0);
    t3 = (t0 + 4312U);
    t4 = *((char **)t3);
    t3 = (t4 + 4);
    t11 = *((unsigned int *)t3);
    t12 = (~(t11));
    t13 = *((unsigned int *)t4);
    t14 = (t13 & t12);
    t15 = (t14 != 0);
    if (t15 > 0)
        goto LAB67;

LAB68:    xsi_set_current_line(66, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 5352);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 5);

LAB69:    goto LAB54;

LAB16:    xsi_set_current_line(67, ng0);
    t3 = (t0 + 4312U);
    t4 = *((char **)t3);
    t3 = (t4 + 4);
    t11 = *((unsigned int *)t3);
    t12 = (~(t11));
    t13 = *((unsigned int *)t4);
    t14 = (t13 & t12);
    t15 = (t14 != 0);
    if (t15 > 0)
        goto LAB70;

LAB71:    xsi_set_current_line(67, ng0);
    t2 = ((char*)((ng9)));
    t3 = (t0 + 5352);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 5);

LAB72:    goto LAB54;

LAB18:    xsi_set_current_line(68, ng0);
    t3 = (t0 + 4312U);
    t4 = *((char **)t3);
    t3 = (t4 + 4);
    t11 = *((unsigned int *)t3);
    t12 = (~(t11));
    t13 = *((unsigned int *)t4);
    t14 = (t13 & t12);
    t15 = (t14 != 0);
    if (t15 > 0)
        goto LAB73;

LAB74:    xsi_set_current_line(68, ng0);
    t2 = ((char*)((ng10)));
    t3 = (t0 + 5352);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 5);

LAB75:    goto LAB54;

LAB20:    xsi_set_current_line(69, ng0);
    t3 = (t0 + 4312U);
    t4 = *((char **)t3);
    t3 = (t4 + 4);
    t11 = *((unsigned int *)t3);
    t12 = (~(t11));
    t13 = *((unsigned int *)t4);
    t14 = (t13 & t12);
    t15 = (t14 != 0);
    if (t15 > 0)
        goto LAB76;

LAB77:    xsi_set_current_line(69, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 5352);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 5);

LAB78:    goto LAB54;

LAB22:    xsi_set_current_line(70, ng0);
    t3 = (t0 + 4312U);
    t4 = *((char **)t3);
    t3 = (t4 + 4);
    t11 = *((unsigned int *)t3);
    t12 = (~(t11));
    t13 = *((unsigned int *)t4);
    t14 = (t13 & t12);
    t15 = (t14 != 0);
    if (t15 > 0)
        goto LAB79;

LAB80:    xsi_set_current_line(70, ng0);
    t2 = ((char*)((ng12)));
    t3 = (t0 + 5352);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 5);

LAB81:    goto LAB54;

LAB24:    xsi_set_current_line(71, ng0);
    t3 = (t0 + 4312U);
    t4 = *((char **)t3);
    t3 = (t4 + 4);
    t11 = *((unsigned int *)t3);
    t12 = (~(t11));
    t13 = *((unsigned int *)t4);
    t14 = (t13 & t12);
    t15 = (t14 != 0);
    if (t15 > 0)
        goto LAB82;

LAB83:    xsi_set_current_line(71, ng0);
    t2 = ((char*)((ng10)));
    t3 = (t0 + 5352);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 5);

LAB84:    goto LAB54;

LAB26:    xsi_set_current_line(73, ng0);
    t3 = (t0 + 4312U);
    t4 = *((char **)t3);
    t3 = (t4 + 4);
    t11 = *((unsigned int *)t3);
    t12 = (~(t11));
    t13 = *((unsigned int *)t4);
    t14 = (t13 & t12);
    t15 = (t14 != 0);
    if (t15 > 0)
        goto LAB85;

LAB86:    xsi_set_current_line(73, ng0);
    t2 = ((char*)((ng5)));
    t3 = (t0 + 5352);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 5);

LAB87:    goto LAB54;

LAB28:    xsi_set_current_line(74, ng0);
    t3 = (t0 + 4312U);
    t4 = *((char **)t3);
    t3 = (t4 + 4);
    t11 = *((unsigned int *)t3);
    t12 = (~(t11));
    t13 = *((unsigned int *)t4);
    t14 = (t13 & t12);
    t15 = (t14 != 0);
    if (t15 > 0)
        goto LAB88;

LAB89:    xsi_set_current_line(74, ng0);
    t2 = ((char*)((ng14)));
    t3 = (t0 + 5352);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 5);

LAB90:    goto LAB54;

LAB30:    xsi_set_current_line(75, ng0);
    t3 = (t0 + 4312U);
    t4 = *((char **)t3);
    t3 = (t4 + 4);
    t11 = *((unsigned int *)t3);
    t12 = (~(t11));
    t13 = *((unsigned int *)t4);
    t14 = (t13 & t12);
    t15 = (t14 != 0);
    if (t15 > 0)
        goto LAB91;

LAB92:    xsi_set_current_line(75, ng0);
    t2 = ((char*)((ng15)));
    t3 = (t0 + 5352);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 5);

LAB93:    goto LAB54;

LAB32:    xsi_set_current_line(76, ng0);
    t3 = (t0 + 4312U);
    t4 = *((char **)t3);
    t3 = (t4 + 4);
    t11 = *((unsigned int *)t3);
    t12 = (~(t11));
    t13 = *((unsigned int *)t4);
    t14 = (t13 & t12);
    t15 = (t14 != 0);
    if (t15 > 0)
        goto LAB94;

LAB95:    xsi_set_current_line(76, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 5352);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 5);

LAB96:    goto LAB54;

LAB34:    xsi_set_current_line(77, ng0);
    t3 = (t0 + 4312U);
    t4 = *((char **)t3);
    t3 = (t4 + 4);
    t11 = *((unsigned int *)t3);
    t12 = (~(t11));
    t13 = *((unsigned int *)t4);
    t14 = (t13 & t12);
    t15 = (t14 != 0);
    if (t15 > 0)
        goto LAB97;

LAB98:    xsi_set_current_line(77, ng0);
    t2 = ((char*)((ng17)));
    t3 = (t0 + 5352);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 5);

LAB99:    goto LAB54;

LAB36:    xsi_set_current_line(78, ng0);
    t3 = (t0 + 4312U);
    t4 = *((char **)t3);
    t3 = (t4 + 4);
    t11 = *((unsigned int *)t3);
    t12 = (~(t11));
    t13 = *((unsigned int *)t4);
    t14 = (t13 & t12);
    t15 = (t14 != 0);
    if (t15 > 0)
        goto LAB100;

LAB101:    xsi_set_current_line(78, ng0);
    t2 = ((char*)((ng18)));
    t3 = (t0 + 5352);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 5);

LAB102:    goto LAB54;

LAB38:    xsi_set_current_line(79, ng0);
    t3 = (t0 + 4312U);
    t4 = *((char **)t3);
    t3 = (t4 + 4);
    t11 = *((unsigned int *)t3);
    t12 = (~(t11));
    t13 = *((unsigned int *)t4);
    t14 = (t13 & t12);
    t15 = (t14 != 0);
    if (t15 > 0)
        goto LAB103;

LAB104:    xsi_set_current_line(79, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 5352);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 5);

LAB105:    goto LAB54;

LAB40:    xsi_set_current_line(80, ng0);
    t3 = (t0 + 4312U);
    t4 = *((char **)t3);
    t3 = (t4 + 4);
    t11 = *((unsigned int *)t3);
    t12 = (~(t11));
    t13 = *((unsigned int *)t4);
    t14 = (t13 & t12);
    t15 = (t14 != 0);
    if (t15 > 0)
        goto LAB106;

LAB107:    xsi_set_current_line(80, ng0);
    t2 = ((char*)((ng12)));
    t3 = (t0 + 5352);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 5);

LAB108:    goto LAB54;

LAB42:    xsi_set_current_line(82, ng0);
    t3 = (t0 + 4312U);
    t4 = *((char **)t3);
    t3 = (t4 + 4);
    t11 = *((unsigned int *)t3);
    t12 = (~(t11));
    t13 = *((unsigned int *)t4);
    t14 = (t13 & t12);
    t15 = (t14 != 0);
    if (t15 > 0)
        goto LAB109;

LAB110:    xsi_set_current_line(82, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 5352);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 5);

LAB111:    goto LAB54;

LAB44:    xsi_set_current_line(83, ng0);
    t3 = (t0 + 4312U);
    t4 = *((char **)t3);
    t3 = (t4 + 4);
    t11 = *((unsigned int *)t3);
    t12 = (~(t11));
    t13 = *((unsigned int *)t4);
    t14 = (t13 & t12);
    t15 = (t14 != 0);
    if (t15 > 0)
        goto LAB112;

LAB113:    xsi_set_current_line(83, ng0);
    t2 = ((char*)((ng21)));
    t3 = (t0 + 5352);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 5);

LAB114:    goto LAB54;

LAB46:    xsi_set_current_line(84, ng0);
    t3 = (t0 + 4312U);
    t4 = *((char **)t3);
    t3 = (t4 + 4);
    t11 = *((unsigned int *)t3);
    t12 = (~(t11));
    t13 = *((unsigned int *)t4);
    t14 = (t13 & t12);
    t15 = (t14 != 0);
    if (t15 > 0)
        goto LAB115;

LAB116:    xsi_set_current_line(84, ng0);
    t2 = ((char*)((ng5)));
    t3 = (t0 + 5352);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 5);

LAB117:    goto LAB54;

LAB48:    xsi_set_current_line(85, ng0);
    t3 = (t0 + 4312U);
    t4 = *((char **)t3);
    t3 = (t4 + 4);
    t11 = *((unsigned int *)t3);
    t12 = (~(t11));
    t13 = *((unsigned int *)t4);
    t14 = (t13 & t12);
    t15 = (t14 != 0);
    if (t15 > 0)
        goto LAB118;

LAB119:    xsi_set_current_line(85, ng0);
    t2 = ((char*)((ng23)));
    t3 = (t0 + 5352);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 5);

LAB120:    goto LAB54;

LAB50:    xsi_set_current_line(86, ng0);
    t3 = (t0 + 4312U);
    t4 = *((char **)t3);
    t3 = (t4 + 4);
    t11 = *((unsigned int *)t3);
    t12 = (~(t11));
    t13 = *((unsigned int *)t4);
    t14 = (t13 & t12);
    t15 = (t14 != 0);
    if (t15 > 0)
        goto LAB121;

LAB122:    xsi_set_current_line(86, ng0);
    t2 = ((char*)((ng5)));
    t3 = (t0 + 5352);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 5);

LAB123:    goto LAB54;

LAB52:    xsi_set_current_line(87, ng0);
    t3 = (t0 + 4312U);
    t4 = *((char **)t3);
    t3 = (t4 + 4);
    t11 = *((unsigned int *)t3);
    t12 = (~(t11));
    t13 = *((unsigned int *)t4);
    t14 = (t13 & t12);
    t15 = (t14 != 0);
    if (t15 > 0)
        goto LAB124;

LAB125:    xsi_set_current_line(87, ng0);
    t2 = ((char*)((ng14)));
    t3 = (t0 + 5352);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 5);

LAB126:    goto LAB54;

LAB55:    xsi_set_current_line(60, ng0);
    t16 = ((char*)((ng2)));
    t17 = (t0 + 5352);
    xsi_vlogvar_assign_value(t17, t16, 0, 0, 5);
    goto LAB57;

LAB58:    xsi_set_current_line(61, ng0);
    t5 = ((char*)((ng2)));
    t7 = (t0 + 5352);
    xsi_vlogvar_assign_value(t7, t5, 0, 0, 5);
    goto LAB60;

LAB61:    xsi_set_current_line(63, ng0);
    t5 = ((char*)((ng4)));
    t7 = (t0 + 5352);
    xsi_vlogvar_assign_value(t7, t5, 0, 0, 5);
    goto LAB63;

LAB64:    xsi_set_current_line(64, ng0);
    t5 = ((char*)((ng6)));
    t7 = (t0 + 5352);
    xsi_vlogvar_assign_value(t7, t5, 0, 0, 5);
    goto LAB66;

LAB67:    xsi_set_current_line(66, ng0);
    t5 = ((char*)((ng8)));
    t7 = (t0 + 5352);
    xsi_vlogvar_assign_value(t7, t5, 0, 0, 5);
    goto LAB69;

LAB70:    xsi_set_current_line(67, ng0);
    t5 = ((char*)((ng2)));
    t7 = (t0 + 5352);
    xsi_vlogvar_assign_value(t7, t5, 0, 0, 5);
    goto LAB72;

LAB73:    xsi_set_current_line(68, ng0);
    t5 = ((char*)((ng4)));
    t7 = (t0 + 5352);
    xsi_vlogvar_assign_value(t7, t5, 0, 0, 5);
    goto LAB75;

LAB76:    xsi_set_current_line(69, ng0);
    t5 = ((char*)((ng11)));
    t7 = (t0 + 5352);
    xsi_vlogvar_assign_value(t7, t5, 0, 0, 5);
    goto LAB78;

LAB79:    xsi_set_current_line(70, ng0);
    t5 = ((char*)((ng2)));
    t7 = (t0 + 5352);
    xsi_vlogvar_assign_value(t7, t5, 0, 0, 5);
    goto LAB81;

LAB82:    xsi_set_current_line(71, ng0);
    t5 = ((char*)((ng4)));
    t7 = (t0 + 5352);
    xsi_vlogvar_assign_value(t7, t5, 0, 0, 5);
    goto LAB84;

LAB85:    xsi_set_current_line(73, ng0);
    t5 = ((char*)((ng13)));
    t7 = (t0 + 5352);
    xsi_vlogvar_assign_value(t7, t5, 0, 0, 5);
    goto LAB87;

LAB88:    xsi_set_current_line(74, ng0);
    t5 = ((char*)((ng6)));
    t7 = (t0 + 5352);
    xsi_vlogvar_assign_value(t7, t5, 0, 0, 5);
    goto LAB90;

LAB91:    xsi_set_current_line(75, ng0);
    t5 = ((char*)((ng13)));
    t7 = (t0 + 5352);
    xsi_vlogvar_assign_value(t7, t5, 0, 0, 5);
    goto LAB93;

LAB94:    xsi_set_current_line(76, ng0);
    t5 = ((char*)((ng16)));
    t7 = (t0 + 5352);
    xsi_vlogvar_assign_value(t7, t5, 0, 0, 5);
    goto LAB96;

LAB97:    xsi_set_current_line(77, ng0);
    t5 = ((char*)((ng2)));
    t7 = (t0 + 5352);
    xsi_vlogvar_assign_value(t7, t5, 0, 0, 5);
    goto LAB99;

LAB100:    xsi_set_current_line(78, ng0);
    t5 = ((char*)((ng4)));
    t7 = (t0 + 5352);
    xsi_vlogvar_assign_value(t7, t5, 0, 0, 5);
    goto LAB102;

LAB103:    xsi_set_current_line(79, ng0);
    t5 = ((char*)((ng19)));
    t7 = (t0 + 5352);
    xsi_vlogvar_assign_value(t7, t5, 0, 0, 5);
    goto LAB105;

LAB106:    xsi_set_current_line(80, ng0);
    t5 = ((char*)((ng2)));
    t7 = (t0 + 5352);
    xsi_vlogvar_assign_value(t7, t5, 0, 0, 5);
    goto LAB108;

LAB109:    xsi_set_current_line(82, ng0);
    t5 = ((char*)((ng20)));
    t7 = (t0 + 5352);
    xsi_vlogvar_assign_value(t7, t5, 0, 0, 5);
    goto LAB111;

LAB112:    xsi_set_current_line(83, ng0);
    t5 = ((char*)((ng2)));
    t7 = (t0 + 5352);
    xsi_vlogvar_assign_value(t7, t5, 0, 0, 5);
    goto LAB114;

LAB115:    xsi_set_current_line(84, ng0);
    t5 = ((char*)((ng22)));
    t7 = (t0 + 5352);
    xsi_vlogvar_assign_value(t7, t5, 0, 0, 5);
    goto LAB117;

LAB118:    xsi_set_current_line(85, ng0);
    t5 = ((char*)((ng6)));
    t7 = (t0 + 5352);
    xsi_vlogvar_assign_value(t7, t5, 0, 0, 5);
    goto LAB120;

LAB121:    xsi_set_current_line(86, ng0);
    t5 = ((char*)((ng24)));
    t7 = (t0 + 5352);
    xsi_vlogvar_assign_value(t7, t5, 0, 0, 5);
    goto LAB123;

LAB124:    xsi_set_current_line(87, ng0);
    t5 = ((char*)((ng6)));
    t7 = (t0 + 5352);
    xsi_vlogvar_assign_value(t7, t5, 0, 0, 5);
    goto LAB126;

}

static void Always_91_2(char *t0)
{
    char t18[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    int t8;
    char *t9;
    char *t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    char *t16;
    char *t17;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    unsigned int t24;
    int t25;

LAB0:    t1 = (t0 + 6768U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(91, ng0);
    t2 = (t0 + 7120);
    *((int *)t2) = 1;
    t3 = (t0 + 6800);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(92, ng0);
    t4 = (t0 + 5192);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);

LAB5:    t7 = ((char*)((ng12)));
    t8 = xsi_vlog_unsigned_case_compare(t6, 5, t7, 5);
    if (t8 == 1)
        goto LAB6;

LAB7:    t2 = ((char*)((ng19)));
    t8 = xsi_vlog_unsigned_case_compare(t6, 5, t2, 5);
    if (t8 == 1)
        goto LAB8;

LAB9:    t2 = ((char*)((ng24)));
    t8 = xsi_vlog_unsigned_case_compare(t6, 5, t2, 5);
    if (t8 == 1)
        goto LAB10;

LAB11:
LAB13:
LAB12:    xsi_set_current_line(96, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 5032);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 3);

LAB14:    goto LAB2;

LAB6:    xsi_set_current_line(93, ng0);
    t9 = (t0 + 4312U);
    t10 = *((char **)t9);
    t9 = (t10 + 4);
    t11 = *((unsigned int *)t9);
    t12 = (~(t11));
    t13 = *((unsigned int *)t10);
    t14 = (t13 & t12);
    t15 = (t14 != 0);
    if (t15 > 0)
        goto LAB15;

LAB16:    xsi_set_current_line(93, ng0);
    t2 = ((char*)((ng27)));
    t3 = (t0 + 5032);
    t4 = (t0 + 5032);
    t5 = (t4 + 72U);
    t7 = *((char **)t5);
    t9 = ((char*)((ng26)));
    xsi_vlog_generic_convert_bit_index(t18, t7, 2, t9, 32, 1);
    t10 = (t18 + 4);
    t11 = *((unsigned int *)t10);
    t8 = (!(t11));
    if (t8 == 1)
        goto LAB20;

LAB21:
LAB17:    goto LAB14;

LAB8:    xsi_set_current_line(94, ng0);
    t3 = (t0 + 4312U);
    t4 = *((char **)t3);
    t3 = (t4 + 4);
    t11 = *((unsigned int *)t3);
    t12 = (~(t11));
    t13 = *((unsigned int *)t4);
    t14 = (t13 & t12);
    t15 = (t14 != 0);
    if (t15 > 0)
        goto LAB22;

LAB23:    xsi_set_current_line(94, ng0);
    t2 = ((char*)((ng25)));
    t3 = (t0 + 5032);
    t4 = (t0 + 5032);
    t5 = (t4 + 72U);
    t7 = *((char **)t5);
    t9 = ((char*)((ng27)));
    xsi_vlog_generic_convert_bit_index(t18, t7, 2, t9, 32, 1);
    t10 = (t18 + 4);
    t11 = *((unsigned int *)t10);
    t8 = (!(t11));
    if (t8 == 1)
        goto LAB27;

LAB28:
LAB24:    goto LAB14;

LAB10:    xsi_set_current_line(95, ng0);
    t3 = (t0 + 4312U);
    t4 = *((char **)t3);
    t3 = (t4 + 4);
    t11 = *((unsigned int *)t3);
    t12 = (~(t11));
    t13 = *((unsigned int *)t4);
    t14 = (t13 & t12);
    t15 = (t14 != 0);
    if (t15 > 0)
        goto LAB29;

LAB30:    xsi_set_current_line(95, ng0);
    t2 = ((char*)((ng27)));
    t3 = (t0 + 5032);
    t4 = (t0 + 5032);
    t5 = (t4 + 72U);
    t7 = *((char **)t5);
    t9 = ((char*)((ng25)));
    xsi_vlog_generic_convert_bit_index(t18, t7, 2, t9, 32, 1);
    t10 = (t18 + 4);
    t11 = *((unsigned int *)t10);
    t8 = (!(t11));
    if (t8 == 1)
        goto LAB34;

LAB35:
LAB31:    goto LAB14;

LAB15:    xsi_set_current_line(93, ng0);
    t16 = ((char*)((ng25)));
    t17 = (t0 + 5032);
    t19 = (t0 + 5032);
    t20 = (t19 + 72U);
    t21 = *((char **)t20);
    t22 = ((char*)((ng26)));
    xsi_vlog_generic_convert_bit_index(t18, t21, 2, t22, 32, 1);
    t23 = (t18 + 4);
    t24 = *((unsigned int *)t23);
    t25 = (!(t24));
    if (t25 == 1)
        goto LAB18;

LAB19:    goto LAB17;

LAB18:    xsi_vlogvar_assign_value(t17, t16, 0, *((unsigned int *)t18), 1);
    goto LAB19;

LAB20:    xsi_vlogvar_assign_value(t3, t2, 0, *((unsigned int *)t18), 1);
    goto LAB21;

LAB22:    xsi_set_current_line(94, ng0);
    t5 = ((char*)((ng27)));
    t7 = (t0 + 5032);
    t9 = (t0 + 5032);
    t10 = (t9 + 72U);
    t16 = *((char **)t10);
    t17 = ((char*)((ng27)));
    xsi_vlog_generic_convert_bit_index(t18, t16, 2, t17, 32, 1);
    t19 = (t18 + 4);
    t24 = *((unsigned int *)t19);
    t25 = (!(t24));
    if (t25 == 1)
        goto LAB25;

LAB26:    goto LAB24;

LAB25:    xsi_vlogvar_assign_value(t7, t5, 0, *((unsigned int *)t18), 1);
    goto LAB26;

LAB27:    xsi_vlogvar_assign_value(t3, t2, 0, *((unsigned int *)t18), 1);
    goto LAB28;

LAB29:    xsi_set_current_line(95, ng0);
    t5 = ((char*)((ng25)));
    t7 = (t0 + 5032);
    t9 = (t0 + 5032);
    t10 = (t9 + 72U);
    t16 = *((char **)t10);
    t17 = ((char*)((ng25)));
    xsi_vlog_generic_convert_bit_index(t18, t16, 2, t17, 32, 1);
    t19 = (t18 + 4);
    t24 = *((unsigned int *)t19);
    t25 = (!(t24));
    if (t25 == 1)
        goto LAB32;

LAB33:    goto LAB31;

LAB32:    xsi_vlogvar_assign_value(t7, t5, 0, *((unsigned int *)t18), 1);
    goto LAB33;

LAB34:    xsi_vlogvar_assign_value(t3, t2, 0, *((unsigned int *)t18), 1);
    goto LAB35;

}


extern void work_m_00000000000703983736_4290951518_init()
{
	static char *pe[] = {(void *)Always_51_0,(void *)Always_58_1,(void *)Always_91_2};
	xsi_register_didat("work_m_00000000000703983736_4290951518", "isim/tb_gas_detector_isim_beh.exe.sim/work/m_00000000000703983736_4290951518.didat");
	xsi_register_executes(pe);
}
