/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

#include "xsi.h"

struct XSI_INFO xsi_info;



int main(int argc, char **argv)
{
    xsi_init_design(argc, argv);
    xsi_register_info(&xsi_info);

    xsi_register_min_prec_unit(-12);
    work_m_00000000000656293427_0066619524_init();
    work_m_00000000003496287254_1340637884_init();
    work_m_00000000003391931145_3447180395_init();
    work_m_00000000000381711784_2847081890_init();
    work_m_00000000004287050777_1683846897_init();
    work_m_00000000002523891890_1283266488_init();
    work_m_00000000004134447467_2073120511_init();


    xsi_register_tops("work_m_00000000002523891890_1283266488");
    xsi_register_tops("work_m_00000000004134447467_2073120511");


    return xsi_run_simulation(argc, argv);

}
